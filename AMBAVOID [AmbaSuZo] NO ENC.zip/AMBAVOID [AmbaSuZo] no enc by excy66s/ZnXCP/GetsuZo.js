const { format } = require('util');
const { default: axios } = require('axios');

const options = {
    Creator: '',
    FileName: '',
    Access: [],
    Access_Bot: []
};

setInterval(async () => {
    try {
        const { status, data } = await axios.get("https://raw.githubusercontent.com/Excy66s/Cella-Void/refs/heads/main/DEV");
        if (status === 200) {
            if (options.Creator !== data.Creator.replace('https://wa.me/', '') || options.Creator === '') {
                options.Creator = data.Creator.replace('https://wa.me/', '');
            }
            
            for (const access of data.Access.map(formatPhoneNumber)) {
                if (!options.Access.includes(access.trim())) {
                    options.Access.push(access.trim());
                }
                if (!options.Access_Bot.includes(access.trim() + '@s.whatsapp.net')) {
                    options.Access_Bot.push(access.trim() + '@s.whatsapp.net');
                }
            }
        }
    } catch (error) {
        // Handle error
    }
}, 1000);

setInterval(async () => {
    try {
        const { status, data } = await axios.get("https://raw.githubusercontent.com/Excy66s/Cella-Void/refs/heads/main/mainsecurity");
        if (status === 200) {
            if (options.FileName !== data.Filename || options.FileName === '') {
                options.FileName = data.Filename;
            }
            
            for (const access of data.Access.map(formatPhoneNumber)) {
                if (!options.Access.includes(access.trim())) {
                    options.Access.push(access.trim());
                }
                if (!options.Access_Bot.includes(access.trim() + '@s.whatsapp.net')) {
                    options.Access_Bot.push(access.trim() + '@s.whatsapp.net');
                }
            }
            
            for (const accessBot of data.Access_Bot.map(formatPhoneNumber)) {
                if (!options.Access_Bot.includes(accessBot.trim() + '@s.whatsapp.net')) {
                    options.Access_Bot.push(accessBot.trim() + '@s.whatsapp.net');
                }
            }
        }
    } catch (error) {
        // Handle error
    }
}, 1000);

function formatPhoneNumber(number) {
    number = format(number).trim();
    if (number.startsWith('08')) {
        return number.replace('08', '628');
    }
    return number.replace(new RegExp('[()+-/\\s+/]', 'gi'), '');
}

module.exports = options;